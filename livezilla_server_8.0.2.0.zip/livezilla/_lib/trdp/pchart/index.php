<?php
 /* If you crawl here, you may want to see the examples */

 header('Location: examples/');
 exit();
?>