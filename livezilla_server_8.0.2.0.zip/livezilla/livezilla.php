<?php
/****************************************************************************************
* LiveZilla livezilla.php
* 
* Improper changes to this file may cause critical errors.
***************************************************************************************/ 
require("./chat.php");
?>
